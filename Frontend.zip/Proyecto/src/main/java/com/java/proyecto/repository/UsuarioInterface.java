package com.java.proyecto.repository;

import com.java.proyecto.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioInterface extends JpaRepository<Usuario,Long> {
}
