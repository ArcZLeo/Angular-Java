package com.java.proyecto.rest;


import com.java.proyecto.model.Documento;
import com.java.proyecto.model.DocumentoDetalle;
import com.java.proyecto.service.DocumentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.print.Doc;
import java.net.URI;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/documento/")
public class DocumentoRest {

    @Autowired
    private DocumentoService documentoService;

    @GetMapping
    private ResponseEntity<List<Documento>> getAllDocument(){
        return ResponseEntity.ok(documentoService.findAll());
    }
    @PostMapping
    private ResponseEntity<Documento> saveDocumento(@RequestBody Documento documento){
        try {
            Documento documentoGuardado = documentoService.save(documento);
            return ResponseEntity.created(new URI("/documento/"+documentoGuardado.getId() )).body(documentoGuardado);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @DeleteMapping(value = "delete/{id}")
    private ResponseEntity<Boolean> deletePersona (@PathVariable ("id") Long id){
        return ResponseEntity.ok(documentoService.deleteByIdR(id));
    }

    @GetMapping ("t/{tipo}")
    private ResponseEntity<List<Documento>> getAllDocumentByTipe (@PathVariable("tipo") String tipo){
        return ResponseEntity.ok(documentoService.findAllTipo(tipo));
    }
    @GetMapping ("n/{num}")
    private ResponseEntity<List<Documento>> getAllDocumentByNum (@PathVariable("num") String num){
        return ResponseEntity.ok(documentoService.findAllNum(num));
    }
    @GetMapping ("a/{asunto}")
    private ResponseEntity<List<Documento>> getAllDocumentByAsunto(@PathVariable("asunto") String asunto){
        return ResponseEntity.ok(documentoService.findAllAsunto(asunto));
    }
    @GetMapping ("f/{fecha}")
    private ResponseEntity<List<Documento>> getAllDocumentByDate (@PathVariable("fecha") Date fecha){
        return ResponseEntity.ok(documentoService.findAllFecha(fecha));
    }

}
