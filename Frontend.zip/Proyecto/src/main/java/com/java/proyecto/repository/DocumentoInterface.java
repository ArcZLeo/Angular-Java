package com.java.proyecto.repository;

import com.java.proyecto.model.Documento;
import com.java.proyecto.model.DocumentoDetalle;
import com.java.proyecto.service.DocumentoService;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DocumentoInterface extends JpaRepository<Documento,Long> {
}
