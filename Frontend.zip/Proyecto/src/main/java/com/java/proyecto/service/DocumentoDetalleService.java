package com.java.proyecto.service;

import com.java.proyecto.model.DocumentoDetalle;
import com.java.proyecto.repository.DocumentoDetalleInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.FluentQuery;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.function.Function;

@Service
public class DocumentoDetalleService implements JpaRepository<DocumentoDetalle, Long> {

    @Autowired
    private DocumentoDetalleInterface documentoDetalleInterface;

    @Override
    public List<DocumentoDetalle> findAll() {
        return documentoDetalleInterface.findAll();
    }

    @Override
    public List<DocumentoDetalle> findAll(Sort sort) {
        return documentoDetalleInterface.findAll(sort);
    }

    @Override
    public Page<DocumentoDetalle> findAll(Pageable pageable) {
        return documentoDetalleInterface.findAll(pageable);
    }

    @Override
    public List<DocumentoDetalle> findAllById(Iterable<Long> longs) {
        return null;
    }

    @Override
    public long count() {
        return 0;
    }


    public Boolean deleteByIdR(Long id) {
        if(documentoDetalleInterface.existsById(id)){
            documentoDetalleInterface.deleteById(id);
            return true;
        }
        else {
            return false;
        }
    }
    @Override
    public void deleteById(Long id) {
            documentoDetalleInterface.deleteById(id);
    }

    @Override
    public void delete(DocumentoDetalle entity) {
        documentoDetalleInterface.delete(entity);
    }

    @Override
    public void deleteAllById(Iterable<? extends Long> longs) {

    }

    @Override
    public void deleteAll(Iterable<? extends DocumentoDetalle> entities) {

    }

    @Override
    public void deleteAll() {

    }

    @Override
    public <S extends DocumentoDetalle> S save(S entity) {
        return documentoDetalleInterface.save(entity);
    }

    @Override
    public <S extends DocumentoDetalle> List<S> saveAll(Iterable<S> entities) {
        return null;
    }

    @Override
    public Optional<DocumentoDetalle> findById(Long aLong) {
        return documentoDetalleInterface.findById(aLong);
    }

    @Override
    public boolean existsById(Long aLong) {
        return false;
    }

    @Override
    public void flush() {

    }

    @Override
    public <S extends DocumentoDetalle> S saveAndFlush(S entity) {
        return null;
    }

    @Override
    public <S extends DocumentoDetalle> List<S> saveAllAndFlush(Iterable<S> entities) {
        return null;
    }

    @Override
    public void deleteAllInBatch(Iterable<DocumentoDetalle> entities) {

    }

    @Override
    public void deleteAllByIdInBatch(Iterable<Long> longs) {

    }

    @Override
    public void deleteAllInBatch() {

    }

    @Override
    public DocumentoDetalle getOne(Long aLong) {
        return null;
    }

    @Override
    public DocumentoDetalle getById(Long aLong) {
        return null;
    }

    @Override
    public DocumentoDetalle getReferenceById(Long aLong) {
        return null;
    }

    @Override
    public <S extends DocumentoDetalle> Optional<S> findOne(Example<S> example) {
        return Optional.empty();
    }

    @Override
    public <S extends DocumentoDetalle> List<S> findAll(Example<S> example) {
        return null;
    }

    @Override
    public <S extends DocumentoDetalle> List<S> findAll(Example<S> example, Sort sort) {
        return null;
    }

    @Override
    public <S extends DocumentoDetalle> Page<S> findAll(Example<S> example, Pageable pageable) {
        return null;
    }

    @Override
    public <S extends DocumentoDetalle> long count(Example<S> example) {
        return 0;
    }

    @Override
    public <S extends DocumentoDetalle> boolean exists(Example<S> example) {
        return false;
    }

    @Override
    public <S extends DocumentoDetalle, R> R findBy(Example<S> example, Function<FluentQuery.FetchableFluentQuery<S>, R> queryFunction) {
        return null;
    }
}
