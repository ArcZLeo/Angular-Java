package com.java.proyecto.model;


import javax.persistence.*;

@Entity
@Table(name = "usuario")
public class Usuario {

    public Usuario(String name, String clave, String tipo, Oficina oficina) {
        super();
        this.name = name;
        this.clave = clave;
        this.tipo = tipo;
        this.oficina = oficina;
    }

    public Usuario() {

    }


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public Oficina getOficina() {
        return oficina;
    }

    public void setOficina(Oficina oficina) {
        this.oficina = oficina;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;

    @Column(nullable = false, length = 100)
    private String name;

    @Column(nullable = false, length = 100)
    private String clave;

    @Column(nullable = false, length = 100)
    private String tipo;


    @ManyToOne
    @JoinColumn(name ="oficina_id", nullable = false)
    private Oficina oficina;


}

