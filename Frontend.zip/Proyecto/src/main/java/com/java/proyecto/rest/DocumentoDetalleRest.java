package com.java.proyecto.rest;

import com.java.proyecto.model.DocumentoDetalle;
import com.java.proyecto.repository.DocumentoDetalleInterface;
import com.java.proyecto.service.DocumentoDetalleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/documentoDetalle/")
public class DocumentoDetalleRest {

    @Autowired
    private DocumentoDetalleService documentoDetalleService;

    @GetMapping
    private ResponseEntity<List<DocumentoDetalle>> getAllDocumentos (){
        return ResponseEntity.ok(documentoDetalleService.findAll());
    }

    @PostMapping
    private ResponseEntity<DocumentoDetalle> saveDocumentoDetalle (@RequestBody DocumentoDetalle documentoDetalle){
        try {
            DocumentoDetalle documuentoGuardado = documentoDetalleService.save(documentoDetalle);
            return ResponseEntity.created(new URI("/documentoDetalle/"+documuentoGuardado.getId())).body(documuentoGuardado);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @DeleteMapping(value = "delete/{id}")
    private ResponseEntity<Boolean> deleteDocumentoDetalle (@PathVariable ("id") Long id){
        return ResponseEntity.ok(documentoDetalleService.deleteByIdR(id));
    }
}
