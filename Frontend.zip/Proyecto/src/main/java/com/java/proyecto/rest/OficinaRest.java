package com.java.proyecto.rest;

import com.java.proyecto.model.Oficina;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.java.proyecto.service.OficinaService;

import java.util.List;

@RestController
@RequestMapping ("/oficina/")
public class OficinaRest {
    @Autowired
    private OficinaService oficinaService;

    @GetMapping
    private ResponseEntity<List<Oficina>> getAllOficina(){

        return ResponseEntity.ok(oficinaService.findAll());
    }
}
