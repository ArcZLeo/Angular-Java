package com.java.proyecto.rest;


import com.java.proyecto.model.Documento;
import com.java.proyecto.model.DocumentoDetalle;
import com.java.proyecto.service.DocumentoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.print.Doc;
import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/documento/")
public class DocumentoRest {

    @Autowired
    private DocumentoService documentoService;

    @GetMapping
    private ResponseEntity<List<Documento>> getAllDocument(){
        return ResponseEntity.ok(documentoService.findAll());
    }
    @PostMapping
    private ResponseEntity<Documento> saveDocumento(@RequestBody Documento documento){
        try {
            Documento documentoGuardado = documentoService.save(documento);
            return ResponseEntity.created(new URI("/documento/"+documentoGuardado.getId() )).body(documentoGuardado);

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
    }

    @DeleteMapping(value = "delete/{id}")
    private ResponseEntity<Boolean> deletePersona (@PathVariable ("id") Long id){
        return ResponseEntity.ok(documentoService.deleteByIdR(id));
    }
}
