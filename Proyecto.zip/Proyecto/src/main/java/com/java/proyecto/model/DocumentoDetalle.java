package com.java.proyecto.model;

import javax.persistence.*;

@Entity
@Table(name = "documento_detalle")
public class DocumentoDetalle {

    public DocumentoDetalle(String observacion, Documento docmuento) {
        super();
        this.observacion = observacion;
        this.docmuento = docmuento;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;


    @Column(nullable = false, length = 100)
    private String observacion;

    @ManyToOne
    @JoinColumn(name ="documento_id", nullable = false)
    private Documento docmuento;

    public DocumentoDetalle() {

    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    public Documento getDocmuento() {
        return docmuento;
    }

    public void setDocmuento(Documento docmuento) {
        this.docmuento = docmuento;
    }
}
