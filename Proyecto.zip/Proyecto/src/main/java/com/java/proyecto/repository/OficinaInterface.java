package com.java.proyecto.repository;

import com.java.proyecto.model.Oficina;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OficinaInterface extends JpaRepository<Oficina,Long> {
}
