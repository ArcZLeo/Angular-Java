package com.java.proyecto.repository;

import com.java.proyecto.model.DocumentoDetalle;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DocumentoDetalleInterface extends JpaRepository<DocumentoDetalle, Long> {
}
